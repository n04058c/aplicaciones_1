/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.Carnet;
import modelo.Conexion;

public class CarnetControlador {

    public boolean crearCarnet(Carnet carnet) {
        String sql = "INSERT INTO carnets (codigo, dni, nombre, apellido, facultad_id, carrera_id) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = Conexion.getConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, carnet.getCodigo());
            ps.setString(2, carnet.getDni());
            ps.setString(3, carnet.getNombre());
            ps.setString(4, carnet.getApellido());
            ps.setInt(5, carnet.getFacultadId());
            ps.setInt(6, carnet.getCarreraId());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Carnet> listarCarnets() {
        List<Carnet> lista = new ArrayList<>();
        String sql = "SELECT * FROM carnets";

        try (Connection conn = Conexion.getConexion(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Carnet c = new Carnet();
                c.setCodigo(rs.getString("codigo"));
                c.setDni(rs.getString("dni"));
                c.setNombre(rs.getString("nombre"));
                c.setApellido(rs.getString("apellido"));
                c.setFacultadId(rs.getInt("facultad_id"));
                c.setCarreraId(rs.getInt("carrera_id"));
                lista.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean eliminarCarnet(String codigo) {
        String sql = "DELETE FROM carnets WHERE codigo = ?";

        try (Connection conn = Conexion.getConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, codigo);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean actualizarCarnet(Carnet carnet) {
        String sql = "UPDATE carnets SET dni=?, nombre=?, apellido=?, facultad_id=?, carrera_id=? WHERE codigo=?";
        try (Connection conn = Conexion.getConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, carnet.getDni());
            ps.setString(2, carnet.getNombre());
            ps.setString(3, carnet.getApellido());
            ps.setInt(4, carnet.getFacultadId());
            ps.setInt(5, carnet.getCarreraId());
            ps.setString(6, carnet.getCodigo());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
