/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Carnet;
import vista.CCarnet;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CarnetControlador implements ActionListener {

    private final CCarnet vista;
    private final String tipo;

    public CarnetControlador(CCarnet vista, String tipo) {
        this.vista = vista;
        this.tipo = tipo;

        this.vista.btnCrear.addActionListener(this);
        this.vista.btnVolver.addActionListener(this);

        if (tipo.equalsIgnoreCase("actualizar")) {
            cargarDatos();
        }
    }

    private void cargarDatos() {
        Carnet seleccionado = MenuControlador.carnetSeleccionado;

        if (seleccionado == null) {
            JOptionPane.showMessageDialog(vista, "No se seleccionó ningún carnet.", "Error", JOptionPane.ERROR_MESSAGE);
            vista.dispose();
            return;
        }

        String codigo = seleccionado.getCodigo();
        String dni = seleccionado.getDni();

        String sql = "SELECT * FROM carnets WHERE codigo = ? AND dni = ?";

        try (Connection conn = conexion.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, codigo);
            stmt.setString(2, dni);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                vista.txtCodigo.setText(codigo);
                vista.txtDni.setText(dni);
                vista.txtNombre.setText(rs.getString("nombre_completo"));
                vista.cmbFacultad.setSelectedItem(rs.getString("facultad"));
                vista.actualizarCarreras();
                vista.cmbCarrera.setSelectedItem(rs.getString("carrera"));

                vista.txtCodigo.setEditable(false);
                vista.txtDni.setEditable(false);
            } else {
                JOptionPane.showMessageDialog(vista, "Carnet no encontrado.", "Aviso", JOptionPane.WARNING_MESSAGE);
                vista.dispose();
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al cargar datos:\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean validarCampos() {
        if (vista.txtCodigo.getText().trim().isEmpty()
                || vista.txtDni.getText().trim().isEmpty()
                || vista.txtNombre.getText().trim().isEmpty()
                || vista.cmbFacultad.getSelectedIndex() == -1
                || vista.cmbCarrera.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(vista, "Todos los campos deben estar completos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private void crearCarnet() {
        String sql = "INSERT INTO carnets (codigo, dni, nombre_completo, facultad, carrera) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = conexion.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, vista.txtCodigo.getText());
            stmt.setString(2, vista.txtDni.getText());
            stmt.setString(3, vista.txtNombre.getText());
            stmt.setString(4, (String) vista.cmbFacultad.getSelectedItem());
            stmt.setString(5, (String) vista.cmbCarrera.getSelectedItem());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(vista, "Carnet creado exitosamente.");
            vista.dispose();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al crear carnet:\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarCarnet() {
        String sql = "UPDATE carnets SET nombre_completo = ?, facultad = ?, carrera = ? WHERE codigo = ? AND dni = ?";

        try (Connection conn = conexion.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, vista.txtNombre.getText());
            stmt.setString(2, (String) vista.cmbFacultad.getSelectedItem());
            stmt.setString(3, (String) vista.cmbCarrera.getSelectedItem());
            stmt.setString(4, vista.txtCodigo.getText());
            stmt.setString(5, vista.txtDni.getText());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(vista, "Carnet actualizado exitosamente.");
            vista.dispose();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al actualizar carnet:\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.btnVolver) {
            vista.dispose();
        } else if (source == vista.btnCrear) {
            if (validarCampos()) {
                if (tipo.equalsIgnoreCase("crear")) {
                    crearCarnet();
                } else if (tipo.equalsIgnoreCase("actualizar")) {
                    actualizarCarnet();
                }
            }
        }
    }
}
