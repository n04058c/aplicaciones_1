/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author gimen
 */
public class ModeloUsuario {
    public String dni;
    public String nombre;
    public String apellido;
    public String contrasena;

    public ModeloUsuario(String dni, String nombre, String apellido, String contrasena) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.contrasena = contrasena;
    }

    public static java.util.ArrayList<ModeloUsuario> listaUsuarios = new java.util.ArrayList<>();
}
