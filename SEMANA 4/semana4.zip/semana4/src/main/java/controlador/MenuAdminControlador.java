/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import vista.MenuAdmin;

public class MenuAdminControlador {

    MenuAdmin vista;
    String figuraSeleccionada = "";

    public MenuAdminControlador(MenuAdmin vista) {
        this.vista = vista;

        // Menú
        vista.itemCuadrado.addActionListener(e -> seleccionarFigura("cuadrado"));
        vista.itemCirculo.addActionListener(e -> seleccionarFigura("circulo"));
        vista.itemRectangulo.addActionListener(e -> seleccionarFigura("rectangulo"));
        vista.itemTriangulo.addActionListener(e -> seleccionarFigura("triangulo"));

        // Botones
        vista.btn_calcular.addActionListener(e -> calcular());
        vista.btn_nuevo.addActionListener(e -> nuevo());
        
        vista.btn_salir.addActionListener(e -> vista.dispose());

        // Escritura en campos
        vista.txt_lado.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                validarInputs();
            }
        });

        vista.txt_base.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                validarInputs();
            }
        });
    }

    public void seleccionarFigura(String figura) {
        figuraSeleccionada = figura;
        vista.txt_lado.setText("");
        vista.txt_base.setText("");
        vista.txt_area.setText("");

        vista.txt_lado.setEnabled(false);
        vista.txt_base.setEnabled(false);
        vista.btn_calcular.setEnabled(false);
        vista.btn_nuevo.setEnabled(false);

        // Habilitar solo lo necesario
        if (figura.equals("cuadrado") || figura.equals("circulo")) {
            vista.txt_lado.setEnabled(true);
        } else {
            vista.txt_lado.setEnabled(true);
            vista.txt_base.setEnabled(true);
        }
    }

    public void validarInputs() {
        boolean campoLleno = !vista.txt_lado.getText().isEmpty();
        boolean campoBase = !vista.txt_base.getText().isEmpty();

        if (figuraSeleccionada.equals("cuadrado") || figuraSeleccionada.equals("circulo")) {
            vista.btn_calcular.setEnabled(campoLleno);
        } else {
            vista.btn_calcular.setEnabled(campoLleno && campoBase);
        }
    }

    public void calcular() {
        try {
            double lado = Double.parseDouble(vista.txt_lado.getText());
            double base = vista.txt_base.isEnabled() ? Double.parseDouble(vista.txt_base.getText()) : 0;
            double area = 0;

            switch (figuraSeleccionada) {
                case "cuadrado":
                    area = lado * lado;
                    break;
                case "circulo":
                    area = Math.PI * lado * lado;
                    break;
                case "rectangulo":
                    area = lado * base;
                    break;
                case "triangulo":
                    area = (lado * base) / 2;
                    break;
            }

            vista.txt_area.setText(String.valueOf(area));
            vista.txt_lado.setEnabled(false);
            vista.txt_base.setEnabled(false);
            vista.btn_calcular.setEnabled(false);
            vista.btn_nuevo.setEnabled(true);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Ingrese números válidos");
        }
    }

    public void nuevo() {
        vista.txt_lado.setText("");
        vista.txt_base.setText("");
        vista.txt_area.setText("");
        vista.btn_calcular.setEnabled(false);
        vista.btn_nuevo.setEnabled(false);

        if (figuraSeleccionada.equals("cuadrado") || figuraSeleccionada.equals("circulo")) {
            vista.txt_lado.setEnabled(true);
        } else {
            vista.txt_lado.setEnabled(true);
            vista.txt_base.setEnabled(true);
        }
    }
}
