/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import javax.swing.JOptionPane;
import modelo.ModeloUsuario;
import vista.RegistroVista;

/**
 *
 * @author gimen
 */
public class RegistroControlador {

    RegistroVista vista;

    public RegistroControlador(RegistroVista vista) {
        this.vista = vista;

        vista.btnCrear.addActionListener(e -> registrarUsuario());
    }

    public void registrarUsuario() {
        String dni = vista.txtDni.getText();
        String nombre = vista.txtNombre.getText();
        String apellido = vista.txtApellido.getText();
        String contrasena = new String(vista.txtContrasena.getPassword());
        String repetir = new String(vista.txtRepetirContrasena.getPassword());

        // Validaciones
        if (dni.isEmpty() || nombre.isEmpty() || apellido.isEmpty() || contrasena.isEmpty() || repetir.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Complete todos los campos");
            return;
        }

        if (!contrasena.equals(repetir)) {
            JOptionPane.showMessageDialog(null, "Las contraseñas no coinciden");
            return;
        }

        for (ModeloUsuario u : ModeloUsuario.listaUsuarios) {
            if (u.dni.equals(dni)) {
                JOptionPane.showMessageDialog(null, "DNI ya registrado");
                return;
            }
        }

        ModeloUsuario nuevo = new ModeloUsuario(dni, nombre, apellido, contrasena);
        ModeloUsuario.listaUsuarios.add(nuevo);
        JOptionPane.showMessageDialog(null, "Usuario registrado correctamente");
    }
}
