/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import javax.swing.JOptionPane;
import modelo.ModeloUsuario;
import vista.LoginVista;

/**
 *
 * @author gimen
 */
public class LoginControlador {

    LoginVista vista;

    public LoginControlador(LoginVista vista) {
        this.vista = vista;

        vista.btnEntrar.addActionListener(e -> ingresar());
        vista.btnSalir.addActionListener(e -> salir());
        vista.btnRegistrar.addActionListener(e -> abrirRegistro());
    }

    public void ingresar() {
        String usuarioIngresado = vista.txt_usuario.getText();
        String contrasenaIngresada = new String(vista.txtContrasena.getPassword());

        if (usuarioIngresado.equals("admin") && contrasenaIngresada.equals("admin")) {
            JOptionPane.showMessageDialog(null, "Bienvenido Admin");
            // Abrir MenuAdmin aquí
        } else {
            boolean encontrado = false;

            for (ModeloUsuario u : ModeloUsuario.listaUsuarios) {
                if (u.dni.equals(usuarioIngresado) && u.contrasena.equals(contrasenaIngresada)) {
                    JOptionPane.showMessageDialog(null, "Bienvenido " + u.nombre);
                    // Abrir Menu Usuario aquí
                    encontrado = true;
                    break;
                }
            }

            if (!encontrado) {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos");
            }
        }
    }

    public void salir() {
        vista.dispose();
    }

    public void abrirRegistro() {
        JOptionPane.showMessageDialog(null, "Aquí abrirías el formulario de registro");
        // Puedes hacer new RegistroVista() y ControladorRegistro
    }
}
