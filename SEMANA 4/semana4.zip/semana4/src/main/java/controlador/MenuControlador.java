/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import vista.Menu;

public class MenuControlador {

    Menu vista;
    String figuraSeleccionada = "";

    public MenuControlador(Menu vista) {
        this.vista = vista;

        // Asociar eventos
        vista.itemCuadrado.addActionListener(e -> seleccionarFigura("cuadrado"));
        vista.itemCirculo.addActionListener(e -> seleccionarFigura("circulo"));

        vista.btnCalcular.addActionListener(e -> calcular());
        vista.btnNuevo.addActionListener(e -> nuevo());

        vista.txt_lado.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                if (!vista.txt_lado.getText().isEmpty()) {
                    vista.btnCalcular.setEnabled(true);
                } else {
                    vista.btnCalcular.setEnabled(false);
                }
            }
        });
    }

    public void seleccionarFigura(String figura) {
        figuraSeleccionada = figura;
        vista.txt_lado.setText("");
        vista.txt_area.setText("");
        vista.txt_lado.setEnabled(true);
        vista.btnCalcular.setEnabled(false);
        vista.btnNuevo.setEnabled(false);
    }

    public void calcular() {
        try {
            double valor = Double.parseDouble(vista.txt_lado.getText());
            double area = 0;

            if (figuraSeleccionada.equals("cuadrado")) {
                area = valor * valor;
            } else if (figuraSeleccionada.equals("circulo")) {
                area = Math.PI * valor * valor;
            }

            vista.txt_area.setText(String.valueOf(area));
            vista.txt_lado.setEnabled(false);
            vista.btnCalcular.setEnabled(false);
            vista.btnNuevo.setEnabled(true);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Ingrese un valor válido");
        }
    }

    public void nuevo() {
        vista.txt_lado.setText("");
        vista.txt_area.setText("");
        vista.txt_lado.setEnabled(true);
        vista.btnCalcular.setEnabled(false);
        vista.btnNuevo.setEnabled(false);
    }
}
