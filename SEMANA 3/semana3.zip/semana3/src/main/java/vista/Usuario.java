/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.util.ArrayList;

/**
 *
 * @author gimen
 */
public class Usuario {

    String dni;
    String nombre;
    String apellido;
    String contrasena;

    // Constructor
    public Usuario(String dni, String nombre, String apellido, String contrasena) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.contrasena = contrasena;
    }

    // Lista estática de usuarios
    public static ArrayList<Usuario> listaDeUsuarios = new ArrayList<>();
}
